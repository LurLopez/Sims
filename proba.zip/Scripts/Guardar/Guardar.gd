extends Node



var save_path = "user://save_game.dat"


var game_data : Dictionary = {
	"Habilidades" : Principales_Variables.Habilidades,
	"First_Time" : First_Time_Global.First_Time
	
} 


func save_game():
	var save_file = FileAccess.open(save_path, FileAccess.WRITE)
	save_file.store_var(game_data)  
	save_file = null

func load_game():
	if FileAccess.file_exists(save_path):
		var save_file = FileAccess.open(save_path,FileAccess.READ)
		game_data=save_file.get_var()
		save_file=null
