
extends Node

# Called when the node enters the scene tree for the first time.
func _ready():
	if (First_Time_Global.First_Time):
		First_Time_Function() # Replace with function body.
		First_Time_Global.First_Time=false
		print(Principales_Variables.Habilidades[2])  
		Guardar.save_game()
		print(First_Time_Global.First_Time)
		Guardar.load_game()
		print(First_Time_Global.First_Time)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	pass









func First_Time_Function():
		print("a")
		Crear_Matriz()
		Crear_Personalidad()
		Crear_Habilidades()





#Creará una matriz de 1339 filas y 574 columnas, llena de "". Las filas representaran los minutos de un día y
#las columnas los dias, que seran de 7 dias por 82 años 
func Crear_Matriz(): 
	var filas = 1339
	var columnas = 574
	for i in range(filas):
		Principales_Variables.Matriz_Jugador.append([]) # Agregar una nueva fila vacía
		for j in range(columnas):
			Principales_Variables.Matriz_Jugador[i].append("") # Llenar con cadenas vacías
			

func Crear_Personalidad():
	var Personalidad_int=Generar_Numero_Aleatorio_Entero(1,3)
	if(Personalidad_int==1):
		Principales_Variables.Personalidad="Trabajador_Compulsivo"
	elif(Personalidad_int==2):
		Principales_Variables.Personalidad="Culo_Del_Sofa"
	elif(Personalidad_int==3):
		Principales_Variables.Personalidad="Deportista"
		


#Se utilizara para crear la personalidad del personaje. Solo se va a utilizará por una vez.

	
func Crear_Habilidades():
	for i in range(0,6):
		
		Principales_Variables.Habilidades.append(Generar_Numero_Aleatorio_Entero(1,100))
		
func Generar_Numero_Aleatorio_Entero(min: int, max: int) -> int:
	var random = RandomNumberGenerator.new()
	random.randomize()  # Inicializa el generador con una semilla aleatoria
	return random.randi_range(min, max)


