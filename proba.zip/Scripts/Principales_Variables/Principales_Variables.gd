extends Node
var Matriz_Jugador=[]
var Personalidad=""
var Habilidades=[] 
